set_perm $MODPATH/system/bin/rclone 0 0 0755
set_perm $MODPATH/system/bin/fusermount 0 0 0755